python3 -u server.py \
  --model_name=freezed.pb \
  --label_file=freezed.label \
  --upload_folder=/tmp
