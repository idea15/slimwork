python3 classify_image.py \
  --model_file freezed.pb \
  --label_file freezed.label \
  --image_file ../test2/7a74d7bae0f0c8293a866c0320f11154fd2b871c.jpg
